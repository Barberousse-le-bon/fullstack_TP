package webserver;

public interface WebServerRouteHandler {
    void run(WebServerContext context);
}
